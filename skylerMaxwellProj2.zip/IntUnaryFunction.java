/** This is a fucntion from integer to the
 *  the same integer
 *  @author Skyler Maxwell
 */
public interface IntUnaryFunction {
    int apply(int x);
}
